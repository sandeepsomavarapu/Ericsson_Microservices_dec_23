package com.ericsson.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan("com.ericsson.springcore")
@Configuration
public class Test {

	public static void main(String[] args) {

		ApplicationContext factory = new AnnotationConfigApplicationContext(Test.class);// eager intializer

		Student stu = (Student) factory.getBean("student");
		System.out.println(stu);// obj address
		System.out.println(stu.getAddress());

	}
	@Bean("student")
	public Student getStudent()
	{
		Student stu=new Student();
				stu.setAddress(getStuAddress());
				return stu;
		
	}
	@Bean
	public Address getStuAddress()
	{
		 
		return new Address();
		
	}

}
