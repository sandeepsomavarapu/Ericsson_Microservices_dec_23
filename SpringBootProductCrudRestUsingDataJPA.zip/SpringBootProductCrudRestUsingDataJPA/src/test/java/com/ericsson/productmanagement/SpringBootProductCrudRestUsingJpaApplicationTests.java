package com.ericsson.productmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProductCrudRestUsingJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
