package com.ericsson.productmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProductCrudRestUsingJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProductCrudRestUsingJpaApplication.class, args);
	}

}
