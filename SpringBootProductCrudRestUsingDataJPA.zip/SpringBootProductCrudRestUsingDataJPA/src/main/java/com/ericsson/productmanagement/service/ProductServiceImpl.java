package com.ericsson.productmanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ericsson.productmanagement.exceptions.ProductNotFound;
import com.ericsson.productmanagement.model.Product;
import com.ericsson.productmanagement.repository.ProductRepo;

@Service
@javax.transaction.Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepo repo;

	@Override
	public String addProduct(Product product) {
		Product product1 = repo.save(product);
		if (product1 != null)
			return "Product Saved successfully";
		else
			return "somthing went wrong";
	}

	@Override
	public String updateProduct(Product product) {
		Product product1 = repo.save(product);
		if (product1 != null)
			return "Product Updated successfully";
		else
			return "somthing went wrong";
	}

	@Override
	public String deleteProduct(int productId) {
		repo.deleteById(productId);
		return "Product Deleted Successfully";
	}

	@Override
	public Product getProduct(int productId) {
		Optional<Product> optional = repo.findById(productId);
		if (optional.isPresent())
			return optional.get();
		else
			throw new ProductNotFound("Product Id Is Invalid");

	}

	@Override
	public List<Product> getAllProducts() {
		return repo.findAll();
	}

	@Override
	public List<Product> getAllProductsBetween(int intialPrice, int finalPrice) {
		return repo.getAllProductsBetween(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) {

		return repo.getAllProductsByCategory(category);
	}

	@Override
	public List<Product> getAllProductsByName(String productName) {
		return repo.getAllProductsByName(productName);
	}

}
