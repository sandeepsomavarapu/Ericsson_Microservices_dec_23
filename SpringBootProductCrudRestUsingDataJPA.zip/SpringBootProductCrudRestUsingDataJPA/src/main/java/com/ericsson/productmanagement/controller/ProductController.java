package com.ericsson.productmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.ericsson.productmanagement.exceptions.ProductNotFound;
import com.ericsson.productmanagement.model.Product;
import com.ericsson.productmanagement.service.ProductService;

/*{"productId":333,
"productName":"lenovo",
"productPrice":9999,
"productDesc":"laptop",
"productCategory":"electronics"
}*/
@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired
	ProductService service;

	@PostMapping("/insertProduct") // http://localhost:8080/products/insertProduct
	public String addProduct(@RequestBody @Validated Product product) {

		return service.addProduct(product);
	}

	@PutMapping("/mergeProduct")
	public String updateProduct(@RequestBody Product product) {// http://localhost:8080/products/mergeProduct
		return service.updateProduct(product);
	}

	@DeleteMapping("/removeProduct/{pid}")
	public String deleteProduct(@PathVariable("pid") int productId) {// http://localhost:8080/products/removeProduct/123
		return service.deleteProduct(productId);
	}

	@GetMapping("/fetchProduct/{pid}")
	public Product getProduct(@PathVariable("pid") int productId) throws ProductNotFound {// http://localhost:8080/products/fetchProduct/123
		return service.getProduct(productId);
	}

	@GetMapping("/fetchAll")
	public List<Product> getAllProducts() {// http://localhost:8080/products/fetchAll
		return service.getAllProducts();
	}

	@GetMapping("/fetchAllBetween/{price1}/{price2}")
	public List<Product> getAllProductsBetween(@PathVariable("price1") int intialPrice,
			@PathVariable("price2") int finalPrice) {// http://localhost:8080/products/fetchAllBetween/12000/15000
		return service.getAllProductsBetween(intialPrice, finalPrice);
	}

	@GetMapping("/fetchAllByCategory/{cat}")
	public List<Product> getAllProductsByCategory(@PathVariable("cat") String category) {// http://localhost:8080/products/fetchAllByCategory/{electronics}
		return service.getAllProductsByCategory(category);
	}

	@GetMapping("/fetchAllByName/{pname}")
	public List<Product> getAllProductsByName(@PathVariable("pname") String productName) {// http://localhost:8080/products/fetchAllByName/samsung
		return service.getAllProductsByName(productName);
	}
	/*
	 * @ResponseStatus(reason = "product id is invalid ")
	 * 
	 * @ExceptionHandler (ProductNotFound.class) public void handleException() {
	 * 
	 * }
	 */

}
