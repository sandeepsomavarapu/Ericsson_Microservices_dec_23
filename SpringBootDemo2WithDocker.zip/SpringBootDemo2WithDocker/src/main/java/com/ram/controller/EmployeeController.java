package com.ram.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {

	@GetMapping("/message")
	public String printMsg() {
		return "welcome to docker ";
	}
}
