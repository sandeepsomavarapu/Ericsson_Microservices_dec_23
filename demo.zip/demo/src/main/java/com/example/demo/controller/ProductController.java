package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/products")
public class ProductController { // http://localhost:9191/products

	List<Product> products = new ArrayList<Product>();

	public ProductController() {
		products.add(new Product(123, "samsung", 2300, "mobile"));
		products.add(new Product(124, "dell", 5300, "laptop"));
		products.add(new Product(125, "apple", 9300, "mobile"));
	}

	// @RequestMapping(method = RequestMethod.GET,value="/getMsg")
	@GetMapping("/getMsg")
	public String sayHello()// http://localhost:9191/products/getMsg
	{

		return "hello everyone!!!";
	}

	@GetMapping("/getProducts")
	public List<Product> getProducts()// http://localhost:9191/products/getProducts
	{
		return products;
	}

	@GetMapping("/getProduct/{pid}")
	public Product getProduct(@PathVariable("pid") int productId)// http://localhost:9191/products/getProduct/123
	{
		for (Product product : products) {
			if (product.getProductId() == productId) {
				return product;
			}
		}
		throw new ArithmeticException("Product Id Is Invalid....");

	}
	@PostMapping("/addProduct")
	public List<Product> addProduct(@RequestBody Product product)// http://localhost:9191/products/getProducts
	{
			products.add(product);
		return products;
	}
}
