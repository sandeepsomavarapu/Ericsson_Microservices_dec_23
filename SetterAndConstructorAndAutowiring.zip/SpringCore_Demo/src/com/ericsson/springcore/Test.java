package com.ericsson.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		
	ApplicationContext factory=new ClassPathXmlApplicationContext("springconfig.xml");//eager intializer 

			Student stu = (Student) factory.getBean("student");
			System.out.println(stu);// obj address
			System.out.println(stu.getAddress());

		
		
	}

}
