package com.cart.Exceptions;

public class NoRecordsException extends RuntimeException {

	public NoRecordsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


}
