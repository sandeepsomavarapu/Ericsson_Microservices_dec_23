package com.ericsson.employeemanagement;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestEmployee {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("mysql");

		EntityManager entityManager = factory.createEntityManager();
		// insert-->persist(),update-->merge(),delete--->remove(),fetch-->find()

//		Employee emp = new Employee("rajesh", 55000, "banglore");

		entityManager.getTransaction().begin();

//		entityManager.persist(emp);

		Employee emp = entityManager.find(Employee.class, 3);

		System.out.println(emp);
//				emp.setEmpAdd("mumbai");
//				emp.setEmpSal(90000);
//				entityManager.merge(emp);

		entityManager.remove(emp);

		entityManager.getTransaction().commit();

	}

}
